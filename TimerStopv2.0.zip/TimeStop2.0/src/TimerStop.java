import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/*
 * Ecrit par Sarathai � 2008
 */

public class TimerStop implements ActionListener, ChangeListener
{
	JFrame fr;					// Variables
	JPanel panel, panel2, panel3, comp, filp, minp, butp, optp, quip;
	JTextField tfm, tff;
	JFileChooser jfc;
	JCheckBox close, exit, itunes, other;
	ButtonGroup grb, grb2;
	String prg;
	JButton ok, st, quit;
	JLabel tim, file, min, line;
	int minute, seconde = 0, i;
	ActionListener tache_timer;
	Timer timer1;
	JMenuBar menu;
	JMenu partie, help;
	JMenuItem quitter, play, stop, restart, appos, aide;;
	
	
	public TimerStop()
	{
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		
		fr = new JFrame();
		fr.setVisible(true);					// Instance de la JFrame
		fr.setTitle("TimerStop v2.0");
		fr.setSize(450,450);
		fr.setLocation((screenSize.width-fr.getWidth())/2, (screenSize.height-fr.getHeight())/2 );
		fr.setResizable(false);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fr.setContentPane(buildContentPane());
		fr.getRootPane().setDefaultButton(ok);

		
		menu = new JMenuBar();			// Le menu et les ActionListeners
		
		partie = new JMenu("Menu");
		
			play = new JMenuItem("D�marrer");
				play.addActionListener(this);
				
			stop = new JMenuItem("Arr�ter");
				stop.addActionListener(this);
				
			quitter = new JMenuItem("Quitter");
				quitter.addActionListener(this);
					
		help = new JMenu("?");
			
			appos = new JMenuItem("A Propos");
				appos.addActionListener(this);
					
			aide = new JMenuItem("Aide");
				aide.addActionListener(this);
			
					
		menu.add(partie);
			partie.add(play);
			partie.add(stop);
			partie.addSeparator();
			partie.add(quitter);
		menu.add(help);
			help.add(aide);
			help.addSeparator();
			help.add(appos);
	fr.setJMenuBar(menu);
	
							// raccourcis clavier
	
	  play.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.getKeyText(KeyEvent.VK_F1)));  
	  stop.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.getKeyText(KeyEvent.VK_F2)));
	  aide.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.getKeyText(KeyEvent.VK_F3)));                 
	  appos.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.getKeyText(KeyEvent.VK_F4)));
	  quitter.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.getKeyText(KeyEvent.VK_F5)));
	}

		
	

	private JPanel buildContentPane()		// Contenu de la JFrame
	{
		panel = new JPanel();
			panel.setLayout(new BorderLayout());
			panel.setBackground(Color.white);
			panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			
		panel2 = new JPanel();
			panel2.setLayout(new BorderLayout());
			
		panel3 = new JPanel();
			panel3.setLayout(new BorderLayout());
			
		comp = new JPanel();
			comp.setLayout(new FlowLayout());
			comp.setBackground(Color.white);
			comp.setBorder(BorderFactory.createTitledBorder("Compte � rebours"));
			
		filp = new JPanel();
			filp.setBackground(Color.white);
			filp.setLayout(new FlowLayout());
			filp.setBorder(BorderFactory.createTitledBorder("Processus � fermer"));
			
		minp = new JPanel();
			minp.setBackground(Color.white);
			minp.setLayout(new FlowLayout());
			minp.setBorder(BorderFactory.createTitledBorder("Nombre de minutes"));
		
		butp = new JPanel();
			butp.setBackground(Color.white);
			butp.setLayout(new FlowLayout());
			
		
		optp = new JPanel();
			optp.setBackground(Color.white);
			optp.setLayout(new GridLayout(5,1));
			optp.setBorder(BorderFactory.createTitledBorder("Options"));
			
		quip = new JPanel();
			quip.setBackground(Color.white);
			quip.setLayout(new FlowLayout());
		
		tfm = new JTextField(10);
				
		tff = new JTextField(28);
			tff.setText("Tappez ici le nom du processus � fermer (ex: itunes, eclipse) sans majuscule, pour conna�tre le nom, faites Ctrl+Alt+Supr, puis onglet processus");

		quit = new JButton("Quitter");
			quit.addActionListener(this);
		
		ok = new JButton("D�marrer");
			ok.addActionListener(this);
			
		st = new JButton("Arr�ter");
			st.addActionListener(this);
			
		tim = new JLabel("" ,SwingConstants.CENTER);
			tim.setText("00:00");
			
		file = new JLabel("Processus : ");
		
		min = new JLabel("Minutes : ");
		
		line = new JLabel("-------------------------------------------------------------------------------------------------------");
		
		close = new JCheckBox("Fermer cette fen�tre � la fin du temps", true);
			close.setBackground(Color.white);
		
		exit = new JCheckBox("Eteindre l'ordinateur � la fin du temps");
			exit.setBackground(Color.white);
			
		itunes = new JCheckBox("Fermer iTunes par d�faut");
			itunes.setBackground(Color.white);
			itunes.addChangeListener(this);
			
		other = new JCheckBox("Fermer le processus entr�", true);
			other.setBackground(Color.white);
			other.addChangeListener(this);
			
		grb = new ButtonGroup();
			grb.add(close);
			grb.add(exit);
		
		grb2 = new ButtonGroup();
			grb2.add(other);
			grb2.add(itunes);
		
		panel.add(panel2, BorderLayout.NORTH);
			panel2.add(filp, BorderLayout.NORTH);
				filp.add(file);
				filp.add(tff);
			panel2.add(minp, BorderLayout.CENTER);
				minp.add(min);
				minp.add(tfm);
			panel2.add(comp, BorderLayout.SOUTH);
				comp.add(tim);
		panel.add(panel3, BorderLayout.CENTER);
			panel3.add(optp, BorderLayout.NORTH);
				optp.add(other);
				optp.add(itunes);
				optp.add(line);
				optp.add(close);
				optp.add(exit);
			panel3.add(butp, BorderLayout.CENTER);
				butp.add(ok);
				butp.add(st);
			panel.add(quip, BorderLayout.SOUTH);
				quip.add(quit);
		
		return panel;
	}

	public void actionPerformed(ActionEvent e) 		// Recupere les ActionListeners du menu et des boutons
	{
		Object src = e.getSource();
		if(ok == src || play == src)
		{
			validerReponse();
			rebours();
			timer1.start();
			fr.getRootPane().setDefaultButton(st);
			ok.setEnabled(false);
			play.setEnabled(false);
			close.setEnabled(false);
			exit.setEnabled(false);
			other.setEnabled(false);
			itunes.setEnabled(false);
			
		}
		else if(stop == src || st == src)
		{
			tim.setText("00:00");
			fr.getRootPane().setDefaultButton(ok);
			timer1.stop();
			close.setEnabled(true);
			other.setEnabled(true);
			itunes.setEnabled(true);
			exit.setEnabled(true);
			ok.setEnabled(true);
			play.setEnabled(true);
			
		}
		else if(aide == src)
		{
			JOptionPane.showMessageDialog(null," Remplissez les champs"
											+ "\n souhait�s pour le compte �"
											+ "\n rebours et cliquez sur \"D�marrer\".",
											"Aide", JOptionPane.INFORMATION_MESSAGE);
		}
		else if(appos == src)
		{
			JOptionPane.showMessageDialog(null, "Ce programme a �t� d�velopp� par Sarathai"
				+ "\n� Copyright 2008",
				"A Propos", JOptionPane.INFORMATION_MESSAGE);
		}
		else if(quitter == src || quit == src)
		{
			System.exit(0);
		}

	}

	public void rebours()		// Methode du compte � rebours
	{
		minute = i;
		seconde = 0;
		 tff.getText();
		 prg = "tskill "+tff.getText();
		tache_timer= new ActionListener()	
		 {
			public void actionPerformed(ActionEvent e1)
			 {
			 seconde--;					// Pour le Timer
			 if(seconde==-1)
			 {
			 seconde=59;
			 minute--;
			 }
			 if(minute==-1)
			 {
				 timer1.stop();
				 

				 if(itunes.isSelected())
				 {
					 try {
		        		  Runtime.getRuntime().exec("tskill itunes"); // Commande Dos simplement fermer Itunes
		        		  										//en cours apres le timer
		        	 } catch (IOException t) {  } 
				 }
				 if(other.isSelected())
				 {
				 try {
		        		  Runtime.getRuntime().exec(""+prg); // Commande Dos simplement fermer un prog choisi
		        		  									    //en cours apres le timer
		        	 } catch (IOException t) {  } 
				 }	
				 
				 if (close.isSelected())
				 {
					 System.exit(0);		// Ferme le programme
				 }
				 if(exit.isSelected())
				 {
					 try {
		        		 Runtime.getRuntime().exec("shutdown -s -t 5 ");	// Eteind le PC commande DOS
		        		 } catch (IOException t) {  } 
				 }
			 }
			 tim.setText(""+minute+":"+seconde);  
			 }
			 };

		 timer1= new Timer(1000,tache_timer);	//Le fameux Timer(le Pr�ccciieuuuxx...)
		
		
	}
	public void validerReponse()		// Pour valider l'entier du timer
	{
		
			if((tfm.getText().trim().compareTo("")==0)|| (!isValide()))	// V�rifie si il y a un charactere au moin												
			{														    // Et s'il est conforme ou non
				
				JOptionPane.showMessageDialog(null, "Veuillez entrer un entier de chiffre.", "Erreur", JOptionPane.ERROR_MESSAGE);
				timer1.stop();
			}
			else
			{
				i = Integer.parseInt(tfm.getText());		// transforme le String JTextFIeld en entier int
	    
			}
			
			
	}

	private boolean isValide() // Methode de si c'est valide ou non
	{
		for(int i = 0; i < tfm.getText().length(); i++)
			if(!isNumeric(tfm.getText().charAt(i))) 
				return false;
		
		return true;
	}
	
	private boolean isNumeric(char c) // Valide si c'est bien un chiffre
	{ 
		String numeric = "0123456789";
		
		for(int i = 0; i < numeric.length(); i++)
			if(c == numeric.charAt(i))
				return true;

		return false;
	}

	public void stateChanged(ChangeEvent e)	// pour les changements du processus � fermer
	{
		if(itunes.isSelected())
		{
			tff.setEnabled(false);
		}
		else if(other.isSelected())
		{
			tff.setEnabled(true);
		}
	}
	
	
	public static void main(String[]args)	// Methode Main
	{
		
		TimerStop stp = new TimerStop();
		stp.fr.setVisible(true);
		
	}


}
